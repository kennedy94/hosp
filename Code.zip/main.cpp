#include "cplex.h"


void timeused(double *time)
{
	static double tstart, tend, tprev;

	if (time == NULL) {
		clock(); /* one extra call to initialize clock */
		tstart = tprev = clock();
	} else {
		tend = clock();
		if (tend < tprev) 
            tstart -= ULONG_MAX; /* wraparound occured */
		tprev = tend;
		*time = (tend-tstart) / CLOCKS_PER_SEC; /* convert to seconds */
	}
}
 
int main(int argc, char *argv[]){

	//imprimir quantas casas decimais?


	char *inst, *saida; 
	if(argc < 2){
		inst = "problema.txt";
		saida = "resultados.txt";
	}
	else{
		if(argc < 3)
			saida = "resultados.txt";
		else
			saida = argv[2];
		inst = argv[1];
		//cout << "Problema n�o configurado para receber entrada pelo prompt!" << endl;
		//exit(0);
	}
	ofstream resultados;
	resultados.open(saida, fstream::app);

	resultados << std::fixed;
    resultados << std::setprecision(4);

	//resultados << "Instancia	" <<  "#Padroes	"<< "#Variaveis	" << "#Variaveis PP	" << "fo RL	" << "tempo RL	" <<   "fo PI	" << "Nos BB	" <<"GAP%	"  << "tempo PI	"<< endl;

		
	resultados << inst;
	cout << " Testando : " << inst << endl; 

	//GECODE
	Problem *modelo = new Problem(inst);
	DFS<Problem> search(modelo);
	double time1, time2;
	ofstream arq;
	arq.open("padroes.txt");
	int contador = 0;
	Problem *sol;
	list<list<float>> padrao;
	int c;
	bool bo = false;
	timeused(NULL);
	while ((sol = search.next())) {
		//para impressao do padrao vazio com o #tamanhos do tipo 0
		if(!bo){
			c = sol->get_k0();
			bo = true;
		}
		list<float> aux;
		//sol->imprimir();
		sol->imprimir_lista(aux);
		padrao.push_back(aux);
		++ contador;
		delete sol;    
	}
	//contabilizar tempo gasto na geracao de padroes
	timeused(&time1);
	//numero de padroes
	arq << contador+1 << endl;
	resultados << "	" << contador+1;
	//imprimir padrao 0
	arq << 0 << " ";
	for(int i = 0; i <= c; i++)
		arq << 0 << " ";
	arq << endl;
	list< list<float> >::iterator it;
	for (it = padrao.begin(); it != padrao.end(); ++it){
		list<float>tl=*it;
		list<float>::iterator itt;	
		for (itt= tl.begin(); itt != tl.end(); itt++)
			arq << *itt << " ";
		arq << endl;
	}
	arq.close();
	delete modelo;
	cout << "Padroes gerados com sucesso!" << endl;
		//--------------------------------------------------------CPLEX part
	int fo;
	//cout << "Digite a funcao objetivo a ser usada: \n - 1: Minimizar sobra total \n - 2: Minimizar formas utilizadas no ultimo periodo\n" << endl;
	//cin >> fo;
	fo = 1;
	
	try{
		Problema_Vigas1	Prob(inst, "padroes.txt");       // pelo cmd
		
		//Prob.heuristica();

		Prob.iniciar_lp(fo, resultados);

		cout << "\n\n\nResolvendo relaxacao linear... \n\n\n";	//resolver relaxacao linear
    	timeused(NULL);
		Prob.resolver_linear();
    	timeused(&time2);
		cout << "\n\nTempo para resolver relaxacao linear: "<< time1 + time2 <<"\n\n";
		Prob.imprimir_solucao(resultados);
		resultados << "	" << time1 + time2;
	}
	catch(...){
		cerr << endl << "\n Erro na resolucao da linear" << endl;
	}
	try {
		Problema_Vigas1	Prob(inst, "padroes.txt");
		cout << "\n\n\nResolvendo Inteira... \n\n";
		Prob.iniciar_lp(fo, resultados);
		Prob.exportar_lp();                   //criar arquivo .lp

		timeused(NULL);
		Prob.revolver_ppl();                    //resolver problema
		timeused(&time2);

		cout << "\n\nTempo do gecode + resolucao do CPLEX gasto (Solucao Inteira): " << time1 + time2 << endl;
		Prob.imprimir_solucao(resultados);
		resultados << "	" << time1 + time2;
	}
	catch (...) {
		cerr << endl << "\n Erro na resolucao da inteira" << endl;
	}
	resultados << endl;

	resultados.close();

    return 0;
}
